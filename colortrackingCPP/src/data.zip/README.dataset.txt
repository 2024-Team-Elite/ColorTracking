# robot-detection > 2024-06-24 4:22am
https://universe.roboflow.com/robotdetection-ckzd9/robot-detection-ciafw

Provided by a Roboflow user
License: CC BY 4.0

